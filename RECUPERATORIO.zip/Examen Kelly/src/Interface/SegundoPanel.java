package Interface;

import javax.swing.*;
import java.awt.*;

public class SegundoPanel extends JPanel {

    private JTextArea mostrarArea;

    public SegundoPanel() {

        setBackground(Color.CYAN);




    }

}
